﻿# Declare variables
$winrmversion = $PSVersionTable.WSManStackVersion.Major

$static_accts = @('dkelly','jyoo','user')

$domainname = [string](Get-WmiObject Win32_ComputerSystem).Domain
$machinename = [string](Get-WmiObject Win32_ComputerSystem).Name
$ips = (get-WmiObject Win32_NetworkAdapterConfiguration)
$usr_dc = ((Get-ADUser krbtgt).DistinguishedName.Split(","))
$dist_name = $usr_dc[$usr_dc.length - 2] + "," + $usr_dc[$usr_dc.length - 1]
$ErrorActionPreference = 'SilentlyContinue'

$dir_letter = ([string]$PWD)[0]
$path1 = "$dir_letter" +  ':\Windows\System32'
$full_path = [string](Get-ChildItem -Path $path1 -Recurse -ErrorAction SilentlyContinue -Include run_script.ps1)
$work_dir = ([string]$full_path).replace("run_script.ps1","")

# Pull updated GPO
function updateGPO{
    Write-Host -ForegroundColor Cyan "`n-------Updating GPO--------`n"
    try{
        Write-Host -ForeGroundColor Green '[+]Pulling and updating GPO'
        gpupdate /force
    }catch{
        $_.Exception.Message
        Write-Host -ForegroundColor Red "[!]GPO could not be pulled correctly, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

function create_local_accts{
    Write-Host -ForegroundColor Cyan "`n-------Adding the local admin accts to AD--------`n"
    $usr_dc = ((Get-ADUser krbtgt).DistinguishedName.Split(","))
    # format the correct distinguished name 
    $dist_name = $usr_dc[$usr_dc.length - 2] + "," + $usr_dc[$usr_dc.length - 1]
    $group = @()
    New-ADGroup -Name "Computer Users-IIS" -SamAccountName ComputerUsersIIS -GroupCategory Security -GroupScope Global -DisplayName "Computer UsersIIS" -Path "CN=Users,$dist_name" -Description "Members of this group are users, ya yeet"
    New-ADGroup -Name "Computer Users-SQL" -SamAccountName ComputerUsersSQL -GroupCategory Security -GroupScope Global -DisplayName "Computer UsersSQL" -Path "CN=Users,$dist_name" -Description "Members of this group are users, ya yeet"
    New-ADGroup -Name "Computer Users-XP" -SamAccountName ComputerUsersXP -GroupCategory Security -GroupScope Global -DisplayName "Computer UsersXP" -Path "CN=Users,$dist_name" -Description "Members of this group are users, ya yeet"
    New-ADGroup -Name "Computer Users-IISr" -SamAccountName ComputerUsersIISr -GroupCategory Security -GroupScope Global -DisplayName "Computer UsersIISr" -Path "CN=Users,$dist_name" -Description "Members of this group are users, ya yeet"
    New-ADGroup -Name "Computer Users-SQLr" -SamAccountName ComputerUsersSQLr -GroupCategory Security -GroupScope Global -DisplayName "Computer UsersSQLr" -Path "CN=Users,$dist_name" -Description "Members of this group are users, ya yeet"
    New-ADGroup -Name "Computer Users-XPr" -SamAccountName ComputerUsersXPr -GroupCategory Security -GroupScope Global -DisplayName "Computer UsersXPr" -Path "CN=Users,$dist_name" -Description "Members of this group are users, ya yeet"
    Write-Host "Waiting 5 seconds for group to be created."
    Start-sleep -s 5
    try{
        $usernames = @('user14','user14r','user16','user16r','user17','user17r','log14','log16','log17')
        $arr = @()
        #$computers = @('WINAD01','WIN2k12IIS','WIN2k8SQL')
        foreach($line in Get-Content "$work_dir\a.txt"){
	        $secure = ConvertTo-SecureString $line -AsPlainText -Force
	        $arr += $secure
        }
        $num = 0
        foreach($user in $usernames){
            New-ADUser -Name $user -AccountPassword $arr[$num] -Enabled $True
            Add-ADGroupMember -Identity "Protected Users" -Members $user
            $num += 1
        }
        Add-AdGroupMember -Identity 'ComputerUsersIIS' -Members log16,user16
        Add-AdGroupMember -Identity 'ComputerUsersIISr' -Members user16r
        Add-AdGroupMember -Identity 'ComputerUsersSQL' -Members log17,user17
        Add-AdGroupMember -Identity 'ComputerUsersSQLr' -Members user17r
        Add-AdGroupMember -Identity 'ComputerUsersXP' -Members log14,user14
        Add-AdGroupMember -Identity 'ComputerUsersXPr' -Members user14r
	'FINISHED ADDING USERS'
        Add-AdGroupMember -Identity 'Remote Desktop Users' -Members ComputerUsersIISr,ComputerUsersSQLr,ComputerUsersXPr

        wmic /node:WIN2K12IIS /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' SPACEFORCEX\ComputerUsersIIS /add ; net localgroup 'Remote Desktop Users' SPACEFORCEX\ComputerUsersIISr /add ; Enable-PSRemoting -Force”
        wmic /node:WIN2K8SQL /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' SPACEFORCEX\ComputerUsersSQL /add ; net localgroup 'Remote Desktop Users' SPACEFORCEX\ComputerUsersSQLr /add ; Enable-PSRemoting -Force”
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Not all local accounts could be created"
        Write-Host "Continue?"
        Read-Host
    }
}

function local_add{
    Write-Host -ForegroundColor Cyan "`n-------Adding accounts to local Admin Group--------`n"

     try{
        $local_adm = @(net localgroup 'Administrators')
        $local_rem = @(net localgroup 'Remote Desktop Users')
        if(($local_adm -match 'ComputerUsers') -and ($local_rem -match 'ComputerUsers')){
            Write-Host -ForegroundColor Green "[+]Groups already added, skipping"
        }else{
            $hostn = hostname
            if($hostn -match 'WIN2K12IIS'){
                net localgroup 'Administrators' SPACEFORCEX\ComputerUsersIIS /add
                net localgroup 'Remote Desktop Users' SPACEFORCEX\ComputerUsersIISr /add
            }elseif($hostn -match 'WIN2k8SQL'){
                net localgroup 'Administrators' SPACEFORCEX\ComputerUsersSQL /add
                net localgroup 'Remote Desktop Users' SPACEFORCEX\ComputerUsersSQLr /add
            }
        }
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Not all local accounts could be added locally!"
        Write-Host "Continue?"
        Read-Host
    }
}

# Change local admin pass / local guest  pass
function localAdminChange{
    Write-Host -ForegroundColor Cyan "`n-------Finding and Changing Local Admin User Password--------`n"
    # Query sids for all users
    # If wmic is erroring, give full path of C:\Windows\System32\wbem\wmic.exe, may not be in path, can also connect with wbemtest.exe to test
    try{
        
        $sids = @(wmic useraccount get sid)
        $user_found = "False"
        foreach ($b in $sids){
            $b = [string]$b.replace(" ","")
            # Hit on only the account ending in -500, as thats the builtin adm for local machines
            if($b | select-string -Pattern '-500$'){
                # Grab name object of -500 acct
                $adminusername = [string](wmic useraccount where sid=`"$b`" get name).replace("Name","")
                $adminusername = $adminusername.replace(" ","")
                wmic useraccount where sid=`"$b`" get domain","name
                $local = [string](wmic useraccount where sid=`"$b`" get localaccount).replace("LocalAccount","")
                $local = $local.replace(" ","")
                $hostname = [string](hostname)
                # looking for local admin and if acct is disabled or not
                if (([string](wmic useraccount where sid=`"$b`" get disabled) | Select-String -Pattern "TRUE") -and ($local -eq "TRUE")){ #($domain -eq $hostname)){
                    # Enable account, or maybe keep disabled, change pass and create new admin user
                    wmic useraccount where sid=`"$b`" set disabled="FALSE"
                    # change pass, will be renamed in GPO
                    net user $adminusername *
                    $user_found = "True"

                }elseif(([string](wmic useraccount where sid=`"$b`" get disabled) | Select-String -Pattern "FALSE") -and ($local -eq "TRUE")){ #($domain -eq $hostname)){
                    # Change acct password, 
                    net user $adminusername *
                    $user_found = "True"
                }
            }
        }
        If ($user_found -eq "False"){
            Write-Host -ForegroundColor Red "`n[!]SID 500 Account was not found, something is wrong, continuing!`n"
            Write-Host -ForegroundColor Yellow "`n[=]Reading from all user accounts, if a user is determined to be admin, please enter the name`n"
            net localgroup Administrators
            wmic useraccount get sid,domain,name,description
            $admin_user = Read-Host
            Write-Host -ForegroundColor Yellow "`n[=]Please enter a new password for the chosen user`n"
            net user $admin_user *
            Write-Host -ForegroundColor Green "[+]Admin User Account password changed!"
        }
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Admin account could not be queried/have their password changed, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Separate function to change find and change pass of local guest acct, even though it will be disabled.
function localGuestChange{
    Write-Host -ForegroundColor Cyan "`n-------Finding and Changing Local Guest User Password--------`n"
    try{
        $sids = @(wmic useraccount get sid)
        $user_found = "False"
        foreach ($b in $sids){
            $b = [string]$b.replace(" ","")
            # Hit on only the account ending in -501, as thats the builtin guest acct for local machines
            if($b | select-string -Pattern '-501$'){
                # Grab name object of -500 acct
                $guestusername = [string](wmic useraccount where sid=`"$b`" get name).replace("Name","")
                $guestusername = $guestusername.replace(" ","")
                wmic useraccount where sid=`"$b`" get domain","name
                $local = [string](wmic useraccount where sid=`"$b`" get localaccount).replace("LocalAccount","")
                $local = $local.replace(" ","")
                $hostname = [string](hostname)
                # looking for local guest and if acct is disabled or not
                if (([string](wmic useraccount where sid=`"$b`" get disabled) | Select-String -Pattern "TRUE") -and ($local -eq "TRUE")){
                    # Enable account, or maybe keep disabled, change pass and create new guest user
                    wmic useraccount where sid=`"$b`" set disabled="FALSE"
                    # change pass, will be renamed in GPO
                    net user $guestusername *
                    $user_found = "True"

                }elseif(([string](wmic useraccount where sid=`"$b`" get disabled) | Select-String -Pattern "FALSE") -and ($local -eq "TRUE")){
                    # Change acct password, 
                    net user $guestusername *
                    $user_found = "True"
                }
            }
        }
        If ($user_found -eq "False"){
            Write-Host -ForegroundColor Red "`n[!]SID 501 Account was not found, something is wrong, continuing!`n"
            Write-Host -ForegroundColor Yellow "`n[=]Reading from all user accounts, if a user is determined to be the guest, please enter the name`n"
            net users
            wmic useraccount get sid,domain,name,description
            $guest_user = Read-Host
            Write-Host -ForegroundColor Yellow "`n[=]Please enter a new password for the chosen user`n"
            net user $guest_user *
            Write-Host -ForegroundColor Green "[+]Guest User Account password changed!"
        }
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Guest account could not be queried/have their password changed, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }

}

function winrmsetup{
    Write-Host -ForegroundColor Cyan "`n-------Setting up WinRM for remote management--------`n"
    try{
        # winrm / remote management steps
        Write-Host -ForegroundColor Yellow "[=]Checking WinRM Stack Version `n"
        Write-Host -ForegroundColor Yellow "[=]Seems to be version $winrmversion"
        netsh advfirewall firewall set rule group="Remote Event Log Management" new enable=yes
        Clear-item -Path WSMan:\localhost\Client\TrustedHosts -Force
        Enable-PSRemoting -Force
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Something went wrong with WinRM setup, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Disable NetBIOS on all adapters
function netbios_disable{
    Write-Host -ForegroundColor Cyan "`n-------Querying NetBIOS setting--------`n"
    # Query for Netbios Registry Key and disable if necessary
    # 0 is enable NetBios from DHCP Server
    # 1 is enable NetBios over TCP/IP
    # 2 is disabled
    try{
        Write-host 'Netbios Registry Keys:'
        $key = "HKLM:SYSTEM\CurrentControlSet\services\NetBT\Parameters\Interfaces" 
        Get-ChildItem $key | foreach {$val = Get-ItemProperty -Path "$key\$($_.pschildname)" -Name NetbiosOptions; If ([int]$val.NetbiosOptions -eq 2){ Write-Host -ForegroundColor Green 'Adapter' $_.pschildname 'has NetBios Disabled!'}ElseIf([int]$val.NetbiosOptions -ne 2){Write-Host -ForegroundColor Red 'Adapter' + $_.pschildname + 'has NetBios Enabled!'}}
        Write-Host -ForegroundColor Yellow '[=]Would you like to disable Netbios across all interfaces?(If already disabled, ignore.  Be Careful, may break functionality for legacy systems)(y/n)'
        $yesorno = Read-Host
        If ($yesorno -eq 'y'){
               Get-ChildItem $key | foreach { Set-ItemProperty -Path "$key\$($_.pschildname)" -Name NetbiosOptions -Value 2 -Verbose}
               Write-Host -ForegroundColor Green '[+]Netbios Disabled'
        }
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]NetBIOS could not be queried/stopped, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}


# Install management roles on management machine
function management_roles{
    Write-Host -ForegroundColor Cyan "`n-------Installing Management Roles--------`n"
    # all roles necessary to manage the environment minus the SQL tool
    try{
        Install-WindowsFeature Remote-Desktop-Services,GPMC,Web-Mgmt-Console,RSAT-Role-Tools,RSAT-AD-PowerShell,RSAT-DHCP,RSAT-DNS-Server -IncludeManagementTools
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Roles could not be installed properly, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# GPO creation and import, make sure backups are located in the run folder
function gpoimport{
    Write-Host -ForegroundColor Cyan "`n-------Importing GPO--------`n"
    # Import-Module GroupPolicy
    try{
        import-gpo -BackupGpoName 2012_Member_Security -TargetName 2012_Member_Security -path $work_dir -CreateIfNeeded | New-GPLink -Target "OU=Servers,$dist_name" -LinkEnabled Yes
        import-gpo -BackupGpoName Domain_Overall -TargetName Domain_Overall -path $work_dir -CreateIfNeeded | New-GPLink -Target "$dist_name" -LinkEnabled Yes
        import-gpo -BackupGpoName Domain_Member_Audit -TargetName Domain_Member_Audit -path $work_dir -CreateIfNeeded | New-GPLink -Target "OU=Servers,$dist_name" -LinkEnabled Yes
        import-gpo -BackupGpoName 2012_DC_Security -TargetName 2012_DC_Security -path $work_dir -CreateIfNeeded | New-GPLink -Target "OU=Domain Controllers,$dist_name" -LinkEnabled Yes
        import-gpo -BackupGpoName DC_Audit -TargetName DC_Audit -path $work_dir -CreateIfNeeded | New-GPLink -Target "OU=Domain Controllers,$dist_name" -LinkEnabled Yes
        #Remove whatever is applied manually, as these defaults may not exist and bad GPO's may exist already
        #Remove-GPLink -Name "Default Domain Policy" -Target "$dist_name"
        #Remove-GPLink -Name "Default Domain Controller Policy" -Target "OU=Domain Controllers,$dist_name"
        Write-Host -ForegroundColor Gray "[+]GPO Successfully Imported!"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]GPO could not be imported, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Create additional AD OU's for each server version
function AD_shimmy{
    Write-Host -ForegroundColor Cyan "`n-------Creating OU for Servers--------`n"
    try{
        # we can grab the distinguished name from something like this: (Get-ADUser username).DistinguishedName
        
        New-ADOrganizationalUnit -Name "Servers" -Path "$dist_name"
        # Display OU's
        Get-ADOrganizationalUnit -Filter 'Name -like "*"' | Format-Table Name, DistinguishedName -A
        Write-Host -ForegroundColor Green "[+]AD OU successfully created!"
        $comps = @(Get-ADComputer -Filter *)
        foreach($comp in $comps){
            if(-Not($comp.DistinguishedName -match "Domain Controllers")){
                Move-ADObject -Identity $comp.DistinguishedName -TargetPath "OU=Servers,$dist_name"
            }
        }
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]OU could not be created, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# install sysmon
function sysmon{
    Write-Host -ForegroundColor Cyan "`n-------Installing Sysmon!--------`n"
    try{
        cp -r "$work_dir\windows" ($dir_letter + ":\Windows\System32\")
        cd "$work_dir\windows"
        ./Sysmon64.exe -i config.xml -n -accepteula -d windows
        Start-sleep -s 5
        Write-Host -ForegroundColor Green "[+]Sysmon installed!"
        # Remove-Item "$work_dir\config.xml"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Sysmon could not be installed, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# baseline
function baseline{
    Write-Host -ForegroundColor Cyan "`n-------Running a baseline!--------`n"
    try{
        # run netstat, firewall show, ipconfig, print to file, and store file
        $filename = $dir_letter + ":\" + $machinename + '_baseline.txt'
        echo "-----Begin baseline for $machinename-----" > $filename
        echo "Run ipconfig:" >> $filename
        ipconfig /all >> $filename
        echo "-----------------------------------" >> $filename
        #echo "Run netstat -nao:" >> $filename
        #netstat -nao >> $filename
        #echo "-----------------------------------" >> $filename
        echo "Run netstat -abn:" >> $filename
        netstat -abn >> $filename
        echo "-----------------------------------" >> $filename
        echo "Run Get Logged on User" >> $filename
        gwmi Win32_LoggedOnUser | Select Antecedent >> $filename
        echo "-----------------------------------" >> $filename
        echo "Run firewall config" >> $filename
        netsh advfirewall show allprofiles >> $filename
        echo "-----------------------------------" >> $filename
        # add firewall rule dump
        Write-Host -ForegroundColor Green "[+]Baseline completed!"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Baseline could not be completed, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# enable firewall logging for different profiles
function firewall_log{
    Write-Host -ForegroundColor Cyan "`n-------Enabling the firewall on this profile and starting logging!--------`n"
    # https://support.microsoft.com/en-us/help/947709/how-to-use-the-netsh-advfirewall-firewall-context-instead-of-the-netsh
    try{
        # domain firewall logging
        Netsh advfirewall set currentprofile state on
        #Set-NetFirewallProfile -name domain,public,private -LogMaxSizeKilobytes 10240 -LogAllowed true -LogBlocked true
        netsh advfirewall set currentprofile logging filename %systemroot%\system32\LogFiles\Firewall\pfirewall.log
        netsh advfirewall set currentprofile logging maxfilesize 4096
        netsh advfirewall set currentprofile logging droppedconnections enable
	netsh advfirewall set rule group="Windows Management Instrumentation (WMI)" new enable=yes
        Write-Host -ForegroundColor Green "[+]Firewall enabled and logging setup!"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Firewall could not be configured properly, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Create a bunch of new DA users for IR to use
function EA_create{
    Write-Host -ForegroundColor Cyan "`n-------Creating EA User--------`n"
    try{
        Write-Host "Enter a password for user: User7 `n"
        $user1_pass = Read-Host -AsSecureString
        New-ADUser -Name "User7" -AccountPassword $user1_pass -Enabled $True
        Add-ADGroupMember -Identity "Enterprise Admins" -Members User7
        Write-Host "Enter a password for user: User10 `n"
        $user10_pass = Read-Host -AsSecureString
        New-ADUser -Name "User10" -AccountPassword $user10_pass -Enabled $True
        Add-ADGroupMember -Identity "Domain Admins" -Members User10
        Add-ADGroupMember -Identity "Enterprise Admins" -Members User7
        Write-Host -ForegroundColor Green "[+]User7 Added to EA group"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Not all accounts could be created, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

function priv_change{
    Write-Host -ForegroundColor Cyan "`n-------Changing passwords for all existing privileged accounts!--------`n"
    try{
        #Iterate through Admin group recursively and change every password
        $accts1 = @(Get-ADGroupMember -Identity "Administrators" -Recursive)
        $accts = @(Get-ADGroupMember -Identity "Administrators" -Recursive).distinguishedName
        Write-Host -ForegroundColor Green "[+]All of the Privileged Users: "
        $num = 0
        $usr = $accts[$num]
        Write-Host -ForegroundColor Yellow "[=]Please enter a password for all Privileged accounts, change these soon after as they may be compromised!!!!!"
        $new_pass_priv = Read-Host -AsSecureString
        Write-Host -ForegroundColor Yellow "Do you want to change the password for the $usr user?(y/n)"
        $addd = Read-Host
        while ($num -ne ($accts.length - 1)){
            if ($addd -eq 'y'){
                Set-ADAccountPassword -Identity $usr -Reset -NewPassword $new_pass_priv 
                Write-Host -ForegroundColor Green "[+]Account $usr password reset"
            }elseif($addd -eq 'n'){
                Write-host -ForegroundColor Yellow "[=]Account $usr password NOT reset"
            }
            $num += 1
            $usr = $accts[$num]
            Write-Host -ForegroundColor Yellow "Do you want to change the password for the $usr user?(y/n)"
            $addd = Read-Host
            
        }
        Write-Host -ForegroundColor Green "`n [+]Password reset, however change them as soon as this script completes to ensure accounts cannot be compromised"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Not all the accounts could have their passwords changed, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

function disable_ipv6{
    Write-Host -ForegroundColor Cyan "`n-------Disabling IPv6--------`n"
    try{
        $adapters = @(Get-NetAdapterBinding)
        foreach ($i in $adapters){
            if($i.ComponentID -eq "ms_tcpip6"){
                Write-Host -ForegroundColor Red "[!]Adapter $i.Name has IPv6 enabled, disabling"
                Disable-NetAdapterBinding -Name $i.Name -ComponentID ms_tcpip6
            }
        }
        Write-Host -ForegroundColor Green "`n[+]IPv6 has been disabled across all adapters`n"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]IPv6 was not able to be stopped, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

function wmi_subscription_block($name, $query, $script){
        
        $Name = $name
        $Query = $query
        $EventNamespace = 'root/cimv2'
        $Class = 'ActiveScriptEventConsumer'

        # Define the signature - i.e. __EventFilter
        $EventFilterArgs = @{
            EventNamespace = $EventNamespace
            Name = $Name
            Query = $Query
            QueryLanguage = 'WQL'
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = '__EventFilter'
            Arguments = $EventFilterArgs
        }
        $Filter = Set-WmiInstance @InstanceArgs

        # Define the Event Consumer - ACTION
        $EventConsumerArgs = @{
            Name = $Name
            ScriptingEngine = 'VBScript'
            ScriptText = 
            'Set objShell = CreateObject("Wscript.shell")
            objShell.run("' + $script + '")'
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = $Class
            Arguments = $EventConsumerArgs
        }
        $Consumer = Set-WmiInstance @InstanceArgs

        $FilterConsumerBingingArgs = @{
            Filter = $Filter
            Consumer = $Consumer
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = '__FilterToConsumerBinding'
            Arguments = $FilterConsumerBingingArgs
        }

        # Register the alert
        $Binding = Set-WmiInstance @InstanceArgs
}

function wmi_subscriptions{
    Write-Host -ForegroundColor Cyan "`n-------Setting up WMI Event Subscriptions--------`n"
    try{
	    cp "$workdir\catch.ps1" C:\Windows\System32\
        #EXAMPLE: wmi_subscription_block 'name' 'query' 'powershell -command {cp c:\Users\a.txt c:\Windows\System32'
	wmi_subscription_block 'tasskmgr' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="Sysmon64" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service Sysmon64'
        wmi_subscription_block 'winlogin' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="TermService" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service TermService'
        wmi_subscription_block 'winIogon' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="MpsSvc" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service MpsSvc'
        wmi_subscription_block 'scvvhost' 'Select * from __InstanceDeletionEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="Sysmon64"' 'powershell C:\Windows\System32\windows\run.ps1'
        Write-Host "Subscriptions Created!"
	    # Get-WmiObject -Namespace 'root/subscription' -Class '__EventFilter' | where-object {$_.Name -like "test*"} | Remove-WmiObject
	    # Get-WmiObject -Namespace 'root/subscription' -Class 'ActiveScriptEventConsumer' | where-object {$_.Name -like "StagingLocation*"} | Remove-WmiObject
	    # Get-WmiObject -Namespace 'root/subscription' -Class '__FilterToConsumerBinding' | where-object {$_.Filter -like "*StagingLocation*"} | Remove-WmiObject
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]WMI Event Subscriptions could not be created, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

function scheduled_tasks{
    Write-Host -ForegroundColor Cyan "`n-------Creating Scheduled Tasks--------`n"
    try{
        
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Scheduled tasks could not be created, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

try {
    echo '' > c:/admin_test.txt
    rm c:/admin_test.txt
    #Begin to ask if DC, DM, or Management machine
    Write-Host -ForegroundColor Green "$machinename"
    Write-Host "Is this machine a 1. DC, 2. member?"
    $machinechoice = Read-Host
    If ($machinechoice -eq 1){
        # Domain controller specific tasks

        Write-Host -ForegroundColor Cyan '[=]You have selected DC, if this is not correct exit the script.'
        Start-Sleep -s 5

        firewall_log
        Start-Sleep -s 2

        baseline
        Start-Sleep -s 2

        management_roles
        Start-Sleep -s 2

        priv_change
        Start-Sleep -s 2

        EA_create
        Start-Sleep -s 2

        create_local_accts
        Start-Sleep -s 2

        ad_shimmy
        Start-Sleep -s 2

        gpoimport
        Start-Sleep -s 2

        #might as well do a catch here in the case that DCOM is open, still do locally just in case
        wmic /node:WIN2K12IIS /user:SPACEFORCEX\User10 process call create “cmd.exe /c gpupdate /force”
        wmic /node:WIN2K8SQL /user:SPACEFORCEX\User10 process call create “cmd.exe /c gpupdate /force”
        Start-Sleep -s 2

        updateGPO
        Start-Sleep -s 2

        sysmon
        Start-Sleep -s 2

        netbios_disable
        Start-Sleep -s 2

        wmi_subscriptions
        Start-Sleep -s 2
        
        Write-Host "[!]Press enter to continue to gpupdate"
        Read-Host

        disable_ipv6
        
    }ElseIf($machinechoice -eq 2){
        # Domain Member specific tasks
        Write-Host -ForegroundColor Cyan '[=]You have selected WIN2k8SQL, if this is not correct exit the script.'
        Start-Sleep -s 5
        
        firewall_log
        Start-Sleep -s 2
        
        baseline
        Start-Sleep -s 2

        netbios_disable
        Start-Sleep -s 2

        sysmon
        Start-Sleep -s 2

        localAdminChange
        Start-Sleep -s 2

        local_add
        Start-Sleep -s 2

        Write-Host "[!]Press enter to continue to gpupdate"
        Read-Host

        updateGPO
        Start-Sleep -s 2

        wmi_subscriptions
        Start-Sleep -s 2

        disable_ipv6

        winrmsetup
        Start-Sleep -s 2


    }ElseIf($machinechoice -eq 'single'){
	Write-Host -ForegroundColor Cyan '[=]You have selected single, if this is not correct exit the script.'
        Start-Sleep -s 5
        # any test function
	    #create_single_comp_accts
        #local_add
        
	
    }
}catch{
 
    $ErrorMessage = $_.Exception.Message
    If ($ErrorMessage | Select-String -Pattern "Denied"){
        Write-Host -ForegroundColor Red $ErrorMessage
        Write-Host -ForegroundColor Red "`n`n[!]Access Denied, restarting as admin, enter credentials if/when prompted"
        $path = "& '$full_path" + "'"
        Start-Process powershell $path -verb runas -Wait; exit
        
    }
    Else{
        Write-Host -ForegroundColor Red "[!]Please assess error message for issue, exiting..."
        $ErrorMessage
        Start-Sleep -s 5
    }
    Write-Host "[!]Exiting!"
}