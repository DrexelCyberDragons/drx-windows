﻿Write-Host 'Block IP address across the organization. Enter an IP address'
$ip = Read-Host
Write-Host 'Enter a rule name'
$name = Read-Host
netsh advfirewall firewall add rule name=$name dir=in interface=any action=block remoteip=$ip
wmic /node:192.168.5.16 /user:SPACEFORCEX\User10 process call create “powershell.exe netsh advfirewall firewall add rule name=$name dir=in interface=any action=block remoteip=$ip"
wmic /node:192.168.5.17 /user:SPACEFORCEX\User10 process call create “powershell.exe netsh advfirewall firewall add rule name=$name dir=in interface=any action=block remoteip=$ip"
