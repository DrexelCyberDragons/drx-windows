﻿$ErrorActionPreference = 'SilentlyContinue'

try{
    $computers = @(Get-ADComputer -Filter *).Name
    $delete_user = @()
    $users = (Get-ADUser -Filter *).SamAccountName
    $new_name_group = @()

    Write-Host "All accts or single computer accts?(all/single) or quit"
    $choice = Read-Host
    while($choice -ne 'quit'){
        if($choice -match 'single'){
            $reach = 'false'
            Write-Host "What is the machine name?Choices are WINAD01,WIN2K12IIS,WIN2K8SQL"
            $comp_name = Read-Host
            if($session -eq 'no'){
                Write-Host -ForegroundColor Red "[!]Cannot reach $comp_name! Users will be created an WMI will be used..."
                $reach = 'false'
            }else{
                $reach = 'true'
                if("WIN2K12IIS" -match $comp_name){
                    #change hosts for this box 
                    Remove-ADUser -Identity user16
                    Remove-ADUser -Identity log16
                    Remove-ADUser -Identity user16r
                    Write-Host "Enter a password for user16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                    Add-AdGroupMember -Identity 'ComputerUsersIIS' -Members log16,user16
		    Add-AdGroupMember -Identity 'Protected Users' -Members user16r,log16,user16
                    Add-AdGroupMember -Identity 'ComputerUsersIISr' -Members user16r
                    wmic /node:192.168.5.16 /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' CHEESE\ComputerUsersIIS /add ; net localgroup 'Remote Desktop Users' CHEESE\ComputerUsersIISr /add”
                }elseif("WIN2K8SQL" -match $comp_name){
                    #change hosts for this box specifically
                    Remove-ADUser -Identity user17
                    Remove-ADUser -Identity log17
                    Remove-ADUser -Identity user17r   
                    Write-Host "Enter a password for user17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user17 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log17 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user17r -AccountPassword $new_pass -Enabled $True
                    Add-AdGroupMember -Identity 'ComputerUsersSQL' -Members log17,user17
                    Add-AdGroupMember -Identity 'ComputerUsersSQLr' -Members user17r
		            Add-AdGroupMember -Identity 'Protected Users' -Members user17r,log17,user17
                    wmic /node:192.168.5.17 /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' CHEESE\ComputerUsersSQL /add ; net localgroup 'Remote Desktop Users' CHEESE\ComputerUsersSQLr /add”
                }elseif("WINAD01" -match $comp_name){
                    Remove-ADUser -Identity User7
                    Write-Host "Enter a password for User7"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user7 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Enterprise Admins" -Members User7
                    Remove-ADUser -Identity User10
                    Write-Host "Enter a password for User10"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user10 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Domain Admins" -Members User10
		    Add-AdGroupMember -Identity 'Protected Users' -Members User7,User10
                }
            }
        }elseif($choice -match 'all'){
            $comps = @('WINAD01','WIN2K12IIS','WIN2K8SQL')
            foreach($comp in $comps){
                if(comp -eq 'WIN2K8SQL'){
                    Remove-ADUser -Identity user17
                    Remove-ADUser -Identity log17
                    Remove-ADUser -Identity user17r        
                    Write-Host "Enter a password for user17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user17 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log17 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user17r -AccountPassword $new_pass -Enabled $True
                    Add-AdGroupMember -Identity 'ComputerUsersSQL' -Members log17,user17
		            Add-AdGroupMember -Identity 'Protected Users' -Members user17r,log17,user17
                    Add-AdGroupMember -Identity 'ComputerUsersSQLr' -Members user17r
                    wmic /node:192.168.5.17 /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' CHEESE\ComputerUsersSQL /add ; net localgroup 'Remote Desktop Users' CHEESE\ComputerUsersSQLr /add”
                }elseif($comp -eq 'WIN2K12IIS'){
                    Remove-ADUser -Identity user16
                    Remove-ADUser -Identity log16
                    Remove-ADUser -Identity user16r
                    Write-Host "Enter a password for user16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                    Add-AdGroupMember -Identity 'ComputerUsersIIS' -Members log16,user16
		            Add-AdGroupMember -Identity 'Protected Users' -Members user16r,log16,user16
                    Add-AdGroupMember -Identity 'ComputerUsersIISr' -Members user16r
                    wmic /node:192.168.5.16 /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' CHEESE\ComputerUsersIIS /add ; net localgroup 'Remote Desktop Users' CHEESE\ComputerUsersIISr /add”
                }elseif($comp -eq 'WINAD01'){
                    Remove-ADUser -Name User7
                    Write-Host "Enter a password for User7"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user7 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Enterprise Admins" -Members User7
                    Remove-ADUser -Name User10
                    Write-Host "Enter a password for User10"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user10 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Domain Admins" -Members User10
		    Add-AdGroupMember -Identity 'Protected Users' -Members User10,User7
                }
            }
        }
    }
}catch{
    $_.Exception
}

