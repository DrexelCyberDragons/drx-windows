﻿$ErrorActionPreference = 'SilentlyContinue'

try{
    $computers = @(Get-ADComputer -Filter *).Name
    $delete_user = @()
    $users = (Get-ADUser -Filter *).SamAccountName
    $new_name_group = @()

    Write-Host "All accts or single computer accts?(all/single) or quit"
    $choice = Read-Host
    while($choice -ne 'quit'){
        if($choice -match 'single'){
            Write-Host "What is the machine name?Choices are AD(User7),IIS(16),SQL(17)"
            #(Get-ADComputer -Filter *).Name
            $comp_name = Read-Host
            $session = New-PSSession -ComputerName $comp_name  -Credential ""
            if($session -eq $null){
                Write-Host -ForegroundColor Red "[!]Cannot reach $comp_name! Please change users manually!"
            }else{
                if("WIN2k12IIS" -match $comp_name){
                    #change hosts for this box 
                    Write-Host "Enter a password for dkelly16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for dkelly16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                    Remove-ADUser -Name dkelly16,jyoo16,user16,log16,dkelly16r,jyoo16r,user16r
                    Invoke-Command -Session $session -ScriptBlock {net localgroup "Administrators" dkelly16,jyoo16,user16,log16 /add; net localgroup "Remote Desktop Users" dkelly16r,jyoo16r,user16r /add}
                }elseif("WIN2k8SQL" -match $comp_name){
                    #change hosts for this box specifically
                    Write-Host "Enter a password for dkelly17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for dkelly17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                    Remove-ADUser -Name dkelly17,jyoo17,user17,log17,dkelly17r,jyoo17r,user17r
                    Invoke-Command -Session $session -ScriptBlock {net localgroup "Administrators" dkelly17,jyoo17,user17,log17 /add; net localgroup "Remote Desktop Users" dkelly17r,jyoo17r,user17r /add}
                }elseif("WINAD01" -match $comp_name){
                    Remove-ADUser -Name User7
                    Write-Host "Enter a password for User7"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user7 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Enterprise Admins" -Members User7
                    Remove-ADUser -Name User10
                    Write-Host "Enter a password for User10"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user10 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Domain Admins" -Members User10
                }
            }
        }elseif($choice -match 'all'){
            $comps = @('WINAD01','WIN2k12IIS','WIN2K8SQL')
            foreach($comp in $comps){
                if(comp -eq 'WIN2K8SQL'){
                    $session = New-PSSession -ComputerName 'WIN2K8SQL' -Credential ""
                    if($session -eq $null){
                        Write-Host -ForegroundColor Red "[!]Cannot reach $comp_name! Please change users manually!"
                    }else{
                        #change hosts for this box specifically
                        Write-Host "Enter a password for dkelly17"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name dkelly16 -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for jyoo17"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name jyoo16 -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for user17"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for log17"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for dkelly17r"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name dkelly16r -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for jyoo17r"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name jyoo16r -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for user17r"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                        Remove-ADUser -Name dkelly17,jyoo17,user17,log17,dkelly17r,jyoo17r,user17r
                        Invoke-Command -Session $session -ScriptBlock {net localgroup "Administrators" dkelly17,jyoo17,user17,log17 /add; net localgroup "Remote Desktop Users" dkelly17r,jyoo17r,user17r /add}
                    }
                }elseif($comp -eq 'WIN2K12IIS'){
                    $session = New-PSSession -ComputerName 'WIN2K12IIS' -Credential ""
                    if($session -eq $null){
                        Write-Host -ForegroundColor Red "[!]Cannot reach $comp_name! Please change users manually!"
                    }else{
                        #change hosts for this box specifically
                        Write-Host "Enter a password for dkelly16"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name dkelly16 -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for jyoo16"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name jyoo16 -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for user16"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for log16"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for dkelly16r"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name dkelly16r -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for jyoo16r"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name jyoo16r -AccountPassword $new_pass -Enabled $True
                        Write-Host "Enter a password for user16r"
                        $new_pass = Read-Host -AsSecureString
                        New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                        Remove-ADUser -Name dkelly16,jyoo16,user16,log16,dkelly16r,jyoo16r,user16r
                        Invoke-Command -Session $session -ScriptBlock {net localgroup "Administrators" dkelly16,jyoo16,user16,log16 /add; net localgroup "Remote Desktop Users" dkelly16r,jyoo16r,user16r /add}
                    }
                }elseif($comp -eq 'WINAD01'){
                    Remove-ADUser -Name User7
                    Write-Host "Enter a password for User7"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user7 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Enterprise Admins" -Members User7
                    Remove-ADUser -Name User10
                    Write-Host "Enter a password for User10"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user10 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Domain Admins" -Members User10
                }
            }
        }
    }
}catch{
    $_.Exception
}

