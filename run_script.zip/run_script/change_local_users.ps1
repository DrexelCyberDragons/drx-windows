﻿$ErrorActionPreference = 'SilentlyContinue'

try{
    $computers = @(Get-ADComputer -Filter *).Name
    $delete_user = @()
    $users = (Get-ADUser -Filter *).SamAccountName
    $new_name_group = @()

    Write-Host "All accts or single computer accts?(all/single) or quit"
    $choice = Read-Host
    while($choice -ne 'quit'){
        if($choice -match 'single'){
            $reach = 'false'
            Write-Host "What is the machine name?Choices are AD(10),IIS(16),SQL(17)"
            #(Get-ADComputer -Filter *).Name
            $comp_name = Read-Host
            $session = New-PSSession -ComputerName $comp_name  -Credential ""
            if($session -eq $null){
                Write-Host -ForegroundColor Red "[!]Cannot reach $comp_name! Users will be created an WMI will be used..."
                $reach = 'false'
            }else{
                $reach = 'true'
                if("WIN2k12IIS" -match $comp_name){
                    #change hosts for this box 
                    Remove-ADUser -Identity dkelly16
                    Remove-ADUser -Identity jyoo16
                    Remove-ADUser -Identity user16
                    Remove-ADUser -Identity log16
                    Remove-ADUser -Identity dkelly16r
                    Remove-ADUser -Identity jyoo16r
                    Remove-ADUser -Identity user16r
                    Write-Host "Enter a password for dkelly16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for dkelly16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                    Add-AdGroupMember -Identity 'ComputerUsersIIS' -Members jyoo16,dkelly16,log16,user16
                    Add-AdGroupMember -Identity 'ComputerUsersIISr' -Members jyoo16r,dkelly16r,user16r
                    wmic /node:WIN2K12IIS /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' CHEESE\ComputerUsersIIS /add ; net localgroup 'Remote Desktop Users' CHEESE\ComputerUsersIISr /add”
                    <#if($reach -eq 'true'){
                        Invoke-Command -Session $session -ScriptBlock {net localgroup "Administrators" dkelly16,jyoo16,user16,log16 /add; net localgroup "Remote Desktop Users" dkelly16r,jyoo16r,user16r /add}
                    }elseif($reach -eq 'false'){
                        Write-Host 'Running against WMI, check locally on machine....'
                        wmic /node:WIN2K12IIS /user:SPACEFORCEX\User10 process call create “cmd.exe /c net localgroup 'Administrators' dkelly16,jyoo16,user16,log16 /add && net localgroup 'Remote Desktop Users' dkelly16r,jyoo16r,user16r /add”
                    }#>
                }elseif("WIN2k8SQL" -match $comp_name){
                    #change hosts for this box specifically
                    Remove-ADUser -Identity dkelly17
                    Remove-ADUser -Identity jyoo17
                    Remove-ADUser -Identity user17
                    Remove-ADUser -Identity log17
                    Remove-ADUser -Identity dkelly17r
                    Remove-ADUser -Identity jyoo17r
                    Remove-ADUser -Identity user17r
                    Write-Host "Enter a password for dkelly17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for dkelly17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                    Add-AdGroupMember -Identity 'ComputerUsersSQL' -Members jyoo17,dkelly17,log17,user17
                    Add-AdGroupMember -Identity 'ComputerUsersSQLr' -Members jyoo17r,dkelly17r,user17r
                    wmic /node:WIN2K8SQL /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' CHEESE\ComputerUsersSQL /add ; net localgroup 'Remote Desktop Users' CHEESE\ComputerUsersSQLr /add”
                    <#if($reach -eq 'true'){
                        Invoke-Command -Session $session -ScriptBlock {net localgroup "Administrators" dkelly17,jyoo17,user17,log17 /add; net localgroup "Remote Desktop Users" dkelly17r,jyoo17r,user17r /add}
                    }elseif($reach -eq 'false'){
                        Write-Host 'Running against WMI, check locally on machine....'
                        wmic /node:WIN2K8SQL /user:SPACEFORCEX\User10 process call create “cmd.exe /c net localgroup 'Administrators' dkelly17,jyoo17,user17,log17 /add; net localgroup 'Remote Desktop Users' dkelly17r,jyoo17r,user17r /add”
                    }#>
                }elseif("WINAD01" -match $comp_name){
                    Remove-ADUser -Identity User7
                    Write-Host "Enter a password for User7"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user7 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Enterprise Admins" -Members User7
                    Remove-ADUser -Identity User10
                    Write-Host "Enter a password for User10"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user10 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Domain Admins" -Members User10
                }
            }
        }elseif($choice -match 'all'){
            $comps = @('WINAD01','WIN2k12IIS','WIN2K8SQL')
            foreach($comp in $comps){
                if(comp -eq 'WIN2K8SQL'){
                    Remove-ADUser -Identity dkelly17
                    Remove-ADUser -Identity jyoo17
                    Remove-ADUser -Identity user17
                    Remove-ADUser -Identity log17
                    Remove-ADUser -Identity dkelly17r
                    Remove-ADUser -Identity jyoo17r
                    Remove-ADUser -Identity user17r
                    Write-Host "Enter a password for dkelly17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log17"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for dkelly17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user17r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                    Add-AdGroupMember -Identity 'ComputerUsersSQL' -Members jyoo17,dkelly17,log17,user17
                    Add-AdGroupMember -Identity 'ComputerUsersSQLr' -Members jyoo17r,dkelly17r,user17r
                    wmic /node:WIN2K8SQL /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' CHEESE\ComputerUsersSQL /add ; net localgroup 'Remote Desktop Users' CHEESE\ComputerUsersSQLr /add”
                    <#$session = New-PSSession -ComputerName 'WIN2K8SQL' -Credential ""
                    if($session -eq $null){
                        Write-Host -ForegroundColor Red "[!]Cannot reach $comp_name! Querying WMI..."
                        wmic /node:WIN2K8SQL /user:SPACEFORCEX\User10 process call create “cmd.exe /c net localgroup 'Administrators' dkelly17,jyoo17,user17,log17 /add; net localgroup 'Remote Desktop Users' dkelly17r,jyoo17r,user17r /add”
                    }else{
                        Invoke-Command -Session $session -ScriptBlock {net localgroup "Administrators" dkelly17,jyoo17,user17,log17 /add; net localgroup "Remote Desktop Users" dkelly17r,jyoo17r,user17r /add}
                    }#>
                }elseif($comp -eq 'WIN2K12IIS'){
                    Remove-ADUser -Identity dkelly16
                    Remove-ADUser -Identity jyoo16
                    Remove-ADUser -Identity user16
                    Remove-ADUser -Identity log16
                    Remove-ADUser -Identity dkelly16r
                    Remove-ADUser -Identity jyoo16r
                    Remove-ADUser -Identity user16r
                    Write-Host "Enter a password for dkelly16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for log16"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name log16 -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for dkelly16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name dkelly16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for jyoo16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name jyoo16r -AccountPassword $new_pass -Enabled $True
                    Write-Host "Enter a password for user16r"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user16r -AccountPassword $new_pass -Enabled $True
                    Add-AdGroupMember -Identity 'ComputerUsersIIS' -Members jyoo16,dkelly16,log16,user16
                    Add-AdGroupMember -Identity 'ComputerUsersIISr' -Members jyoo16r,dkelly16r,user16r
                    wmic /node:WIN2K12IIS /user:SPACEFORCEX\User10 process call create “powershell.exe net localgroup 'Administrators' CHEESE\ComputerUsersIIS /add ; net localgroup 'Remote Desktop Users' CHEESE\ComputerUsersIISr /add”
                    <#$session = New-PSSession -ComputerName 'WIN2K12IIS' -Credential ""
                    if($session -eq $null){
                        Write-Host -ForegroundColor Red "[!]Cannot reach $comp_name! Querying WMI..."
                        wmic /node:WIN2K12IIS /user:SPACEFORCEX\User10 process call create “cmd.exe /c net localgroup 'Administrators' dkelly16,jyoo16,user16,log16 /add && net localgroup 'Remote Desktop Users' dkelly16r,jyoo16r,user16r /add”  
                    }else{
                        #change hosts for this box specifically
                        Invoke-Command -Session $session -ScriptBlock {net localgroup "Administrators" dkelly16,jyoo16,user16,log16 /add; net localgroup "Remote Desktop Users" dkelly16r,jyoo16r,user16r /add}
                    }#>
                }elseif($comp -eq 'WINAD01'){
                    Remove-ADUser -Name User7
                    Write-Host "Enter a password for User7"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user7 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Enterprise Admins" -Members User7
                    Remove-ADUser -Name User10
                    Write-Host "Enter a password for User10"
                    $new_pass = Read-Host -AsSecureString
                    New-ADUser -Name user10 -AccountPassword $new_pass -Enabled $True
                    Add-ADGroupMember -Identity "Domain Admins" -Members User10
                }
            }
        }
    }
}catch{
    $_.Exception
}

